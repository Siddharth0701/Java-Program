import java.util.Scanner;
class fibonacciSeries
{
public static void main(String args[])
	{
	int a=0,b=1;
	int c;
	System.out.println(a);
	System.out.println(b);
	Scanner obj=new Scanner(System.in);
	int size;
	System.obj.println("Enter the size");
	for(i=1;i<=size;i++)
		{
		c=a+b;
		System.out.println(c);
		a=b;
		b=c;
		}
	}
	System.out.println("Fibonacci Series is:");
}