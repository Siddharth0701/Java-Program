class Minimum
{
public static void main(String args[])
{
int n1,n2;
n1=20;
n2=30;
if(n1<n2)
{
System.out.println("n1_is_Minimum");
}
else
{
System.out.println("n2_is_Minimum");
}
}
}