class Minimum
{
public static void main(String args[])
{
int a,b;
a=20;
b=30;
if(a<b)
{
System.out.println(Minimum_is_a);
}
else
{
System.out.println(Minimum_is_b);
}
}
}