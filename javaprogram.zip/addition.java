class addition
{
public static void main(String arg[])
{
int A,B,C;
A=12;
B=30;
C=A+B;
System.out.println(C); 
}
}
