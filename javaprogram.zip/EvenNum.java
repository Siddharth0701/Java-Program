import java.util.Scanner;
class EvenNum
{ 
public static void main(String args[])
	{
	for(int i=2;i<=50;i++)
		{
		if(i%2==0)
			{
			System.out.println(i);
			}
		}
	}
}